@php
	$version = request('version');
@endphp

	<div class="flex flex-wrap justify-between">
		@if( isset($data['books']) )
			<div class="flex-1 border border-gray-600 p-2">
				<h1>
					<strong>Vechiul Testament</strong>
				</h1>
				<ul>
					@for ($i=0;$i<count($data['books']['data']);$i++)
						<a class="block hover:bg-gray-300" 
							href="/traduceri/{{$version}}/carti/{{$data['books']['data'][$i]['slug']}}/capitole">
							{{ $data['books']['data'][$i]['name'] }}
						</a>
						@if ($i==37)
							@break
						@endif
					@endfor
				</ul>
			</div>

			<div class="flex-1 border border-gray-600 p-2">
				<h1>
					<strong>Noul Testament</strong>
				</h1>
				<ul>
					@for ($i=37;$i<count($data['books']['data']);$i++)
						<a class="block hover:bg-gray-300" 
							href="/traduceri/{{$version}}/carti/{{$data['books']['data'][$i]['name']}}/capitole">
							{{ $data['books']['data'][$i]['name'] }}
						</a>
						@if ($i==37)
							@break
						@endif
					@endfor
				</ul>
			</div>
		@endif
	</div>
	@can('create', \App\Book::class)
		@include('bible.buttons.edit_bible_resource_btn')
		@if( request('edit') )
			@include('bible.forms.edit_books')
		@endif
		
		@include('bible.forms.add_book')
	@endcan