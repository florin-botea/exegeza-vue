@php
	$version = request('version');
	$book = request('book');
	$chapter = request('chapter');
	$verses_preview = \Session::get('verses_preview');
@endphp

<div class="py-2" id="books_chapters">
	<div class="mt-3" id="chapter_content">
		@can('create', App\Chapter::class)
		<div class="">
			<a class="ml-auto" href="?edit=true">
				@include('bible.buttons.edit_bible_resource_btn')
			</a>
			@if ( request('edit') && request('chapter') )
				@include('bible.forms.add_verses')
			@endif
		</div>
		@endcan
	
		<div class="p-2 ml-4 shadow-md">
			@if( $verses_preview )
				<div id="preview-output" class="bg-light">
					@foreach( $verses_preview as $index => $verse )
						<p class="list-group-item-action m-0"> {{ $index + 1 .'. '. $verse }} </p>
					@endforeach
				</div>
				@else 
				<the-verse-section></the-verse-section>
			@endif
		</div>
	</div>
</div>