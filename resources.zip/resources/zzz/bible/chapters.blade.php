@php
	$verses_preview = \Session::get('verses_preview');
@endphp

<div class="absolute w-full overflow-y-auto" id="chapters_verses">
	<div class="">
		<div class="bg-orange-100">
			<div class="p-2 m-2 layers-color-schema shadow-md">
				@include('bible.breadcrumb')
			</div>
			<div class="p-2 m-2 layers-color-schema border-b-2 border-gray-500 shadow-2xl">
				<nav aria-label="...">
					<ul class="flex flex-wrap">
						@foreach( $data['chapters']['data'] as $_chapter )
							@if( $_chapter->index == request('chapter') )
								<a class="bg-yellow-300 px-2 shadow-lg border border-gray-400 rounded m-1 font-semibold" aria-current="page" title="{{ $_chapter->text }}">
									{{ $_chapter->index }}
								</a>
								@else
								<a class="hover:text-blue-500 shadow-lg border border-gray-400 font-semibold cursor-pointer px-2 rounded m-1" title="{{ $_chapter->text }}"
								href="{{route('traduceri.carti.capitole.versete.index', ['version' => request('version'), 'book' => request('book'), 'capitol' => $_chapter->index])}}">
										{{ $_chapter->index }}
								</a>
							@endif
						@endforeach
					</ul>
				</nav>
				<br>
				<div class="flex">
					<button class="hover:text-blue-500 shadow-lg border border-gray-400 font-semibold cursor-pointer rounded px-4" 
						onclick="location.href='{{ request('chapter') > 1 ? route('traduceri.carti.capitole.versete.index', ['version' => request('version'), 'book' => request('book'), 'capitol' => request('chapter')-1]) : route('traduceri.carti.capitole.index', ['version' => request('version'), 'book' => request('book')])}}'"
						{{ request('chapter') > 0 ? '' : 'disabled=true' }} >
						<i class="fas fa-arrow-left"></i>
					</button>
					<button class="hover:text-blue-500 shadow-lg border border-gray-400 font-semibold cursor-pointer rounded px-4 ml-auto"
						onclick="location.href='{{route('traduceri.carti.capitole.versete.index', ['version' => request('version'), 'book' => request('book'), 'capitol' => request('chapter')+1])}}'"
						{{ count($data['chapters']['data']) >= request('chapter')+1 ? '' : 'disabled=true' }} >
						<i class="fas fa-arrow-right"></i>
					</button>
				</div>
			</div>
		</div>
		<hr>
		
		@if( request('edit') && !request('chapter') && auth()->user() && auth()->user()->hasRole('admin') )
			@include('bible.forms.edit_chapters')
			<br>
			<hr>
		@endif
		@if( !request('chapter') && auth()->user() && auth()->user()->hasRole('admin') )
			@include('bible.buttons.edit_bible_resource_btn')
			@include('bible.forms.add_chapter')
		@endif
		@if( request('chapter') )
			@include('bible.verses')
			@else
				<comment-section-show-icon/>
		@endif
	</div>
</div>