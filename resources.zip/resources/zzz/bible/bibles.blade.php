@extends('layouts.bibles_books')

@section('content')	
	@can('create', \App\Bible::class)
		@include('bible.buttons.edit_bible_resource_btn')
		@if( request('edit') )
			@include('bible.forms.edit_versions')
		@endif
		
		@include('bible.forms.add_version')
	@endcan
@endsection