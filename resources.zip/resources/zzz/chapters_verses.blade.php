@extends('layouts.app')

@php

@endphp

@section('content')
	<div class="flex-1 flex flex-wrap relative w-full h-full">
		<verses-section-wrapper class="w-full h-full relative md:w-1/2 bg-yellow-100 overflow-y-auto">
			@include('bible.chapters')
		</verses-section-wrapper>
		
		<the-comment-section class="w-0 md:w-1/2 absolute right-0 md:relative h-full bg-yellow-100 overflow-y-auto z-30"></the-comment-section>
	</div>
@stop