@extends('layouts.app')
	
@section('content')
	<!--div class="absolute flex flex-wrap overflow-y-auto"-->
	<div class="w-full h-full flex flex-wrap overflow-y-auto">
		<div class="w-full md:w-1/3 order-last md:order-first">
		<!--shadow-lg border-r-2 border-t-2 border-gray-300-->
			@include('bible.search')
		</div>
		
		<div class="w-full md:w-2/3 shadow-lg">
			<div class="px-4 py-2 m-2 layers-color-schema shadow-md">
				@include('bible.breadcrumb')
			</div>
			<div class="p-4 m-2 layers-color-schema shadow-md">
				@yield('content')
			</div>
		</div>
	</div>
@stop