<template>
	<NotificationList></NotificationList>
</template>

<script>
import NotificationList from './_components/NotificationList.vue';

export default {
	name: 'NotificationModule',
	components: {
		NotificationList
	}
}
</script>