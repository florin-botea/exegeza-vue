export default {
	name: 'navbar',
	mutations: {
		t(){
			alert(1)
		}
	}
}