<template>
	<CommentList></CommentList>
</template>

<script>
import CommentList from './_components/CommentList.vue';

export default {
	name: 'CommentModule',
	components: {
		CommentList
	},
}
</script>

<style>

</style>