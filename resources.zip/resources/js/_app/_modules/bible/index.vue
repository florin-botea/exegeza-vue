<template>
	<VersesSection></VersesSection>
</template>

<script>
import VersesSection from './_components/VersesSection.vue'

export default {
	name: 'BibleModule',
	components: {
		VersesSection
	},
	created() {

	},
}
</script>